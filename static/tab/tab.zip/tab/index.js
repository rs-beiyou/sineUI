define(function (require, exports, module) {
    require('./tab.css');
    var parent = window.top.document;
    var randomString = function (len) {
      len = len || 32;
      /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
      var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';
      var maxPos = $chars.length;
      var pwd = '';
      for (var i = 0; i < len; i++) {
        pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
      }
      return pwd;
    }
    var defaults = {
      title: "",
      url: "", //tab iframe url
      id: "",
      content: "",
      close: true,
      hasParentTab: true
    }
    var Tab = function () {
      this.$page = $('.si-page');
      this.$topbar = $('.si-sider-topbar');
      this.$tab = $('.btsp-nav-tabs');
      this.$tabContent = $('.si-page-content');
      
      this.$container = null;
      this.$tabLeft = null;
      this.$tabRight = null;
      this.$tabContentObj = {};
      this.activeTab = 'bsIndex';
      this.tabArr = ['bsIndex'];
      this.maxWidth = 0;
      this.tabWidth = 0;
      this.timer = null;
      this.init();
    }
    Tab.prototype = {
      init: function () {
        var _this = this;
        this.$topbar.on('click',function() {
          _this.$page.toggleClass('si-page-left-hide');
        });
        this.$tab.wrap('<div class="tab-header"></div>');
        this.$container = this.$tab.parent();
        this.$tabContentObj['bsIndex'] = {
          $li: this.$tab.children('li:first'),
          $content: this.$tabContent.children('div:first')
        }
        this.$tab.on('click', '[tabClose]', function (e) {
          e = window.event || e;
          if (document.all) { //只有ie识别
            e.cancelBubble = true;
          } else {
            e.stopPropagation();
          }
          var id = $(e.target).attr('tabClose');
          _this.closeTab(id)
        });
        this.$tab.on('click', function (e) {
          e = window.event || e;
          var target = $(e.target);
          if (target.is('i')) return;
          _this.activeTab = target.attr('data-panel') || 'bsIndex';
        });
        this.addControler();
        this.triggerScroll();
      },
      addControler: function(){
        var _controler = document.createElement('div'),
          _dropdown = document.createElement('div'),
          _btn = '<button class="btn btn-sm btn-primary" id="si_tab_controler" data-toggle="dropdown">标签选项<i class="fa fa-caret-down fa-fw"></i></button>',
          _link = '<ul class="dropdown-menu dropdown-menu-right" aria-labelledby="si_tab_controler">'+
                    '<li data-target="refreshTab"><a href="javascript:;">刷新</a></li>'+
                    '<li data-target="closeTab"><a href="javascript:;">关闭</a></li>'+
                    '<li role="separator" class="divider"></li>'+
                    '<li data-target="closeAll"><a href="javascript:;">关闭所有</a></li>'+
                    '<li data-target="closeOthers"><a href="javascript:;">关闭其他</a></li>'+
                  '</ul>'
          $controler = $(_controler),
          $dropdown = $(_dropdown);
        var _this = this;
        $dropdown.addClass('si-tab-dropdown').append(_btn).append(_link);
        $controler.addClass('si-tab-controler').append(_dropdown);
        $dropdown.on('click','li',function(e){
          var $this = $(this), data = $this.data('target');
          data && _this[data]();
        });
        this.$container.append(_controler);
      },
      addTabs: function (options) {
        var _this = this;
        var op = $.extend({}, defaults, options || {})
        op.url = op.url.indexOf(webRoot) === 0 ? op.url : webRoot + op.url;
        op.id = op.id !== '' ? "tab_" + op.id : randomString(10);
  
        if (!this.$tabContentObj[op.id]) {
          var mainHeight = parent.documentElement.clientHeight - 130;
          var _li = document.createElement('li'),
            _a = document.createElement('a'),
            $li = $(_li),
            $a = $(_a);
          $a.attr({
            href: '#' + op.id,
            role: 'tab',
            'aria-controls': op.id,
            'data-toggle': 'tab',
            'data-panel': op.id
          }).html(op.title);
          if (op.close) {
            var _i = document.createElement('i'),
              $i = $(_i);
            $i.addClass('fa fa-times fa-fw').attr({
              'tabClose': op.id
            });
            $a.append(_i);
          }
          $li.attr({
            'data-toggle': 'context',
            'data-target': '#context-menu',
            'data-panel': op.id,
          }).html(_a);
          //TAB内容
          var _content = document.createElement('div'),
            $content = $(_content);
          $content.attr({
            role: 'tabpanel',
            id: op.id
          }).addClass('tab-pane');
          if (options.content) {
            $content.html(options.content);
          } else {
            var _iframe = document.createElement('iframe'),
              $iframe = $(_iframe);
            $iframe.attr({
              src: op.url,
              width: '100%',
              height: '100%',
              frameborder: 'no',
              border: '0',
              marginwidth: '0',
              marginheight: '0',
              scrolling: 'yes',
              allowtransparency: 'yes'
            });
            $content.html(_iframe);
          }
          this.$tabContentObj[op.id] = {
            $li: $li,
            $content: $content,
            parent: op.hasParentTab ? this.activeTab : ''
          };
  
          this.tabArr.push(op.id);
          this.$tab.append(_li);
          this.$tabContent.append(_content);
          this.triggerScroll();
        }
        this.$tabContentObj[this.activeTab].$li.removeClass('active');
        this.$tabContentObj[this.activeTab].$content.removeClass('active');
        this.activeTab = op.id;
        this.$tabContentObj[this.activeTab].$li.addClass('active');
        this.$tabContentObj[this.activeTab].$content.addClass('active');
      },
      closeTab: function (id) {
        id = id || this.activeTab;
        if(id === 'bsIndex')return;
        var tabObj = this.$tabContentObj;
        var tabArr = this.tabArr;
        tabObj[id].$li.remove();
        tabObj[id].$content.remove();
        tabObj[id] = null;
        tabArr.splice(tabArr.indexOf(id), 1);
        var activeTab = tabArr[tabArr.length - 1];
        tabObj[activeTab].$li.addClass('active');
        tabObj[activeTab].$content.addClass('active');
        this.activeTab = activeTab;
        this.triggerScroll();
      },
      closeAll: function(){
        var tabObj = this.$tabContentObj;
        tabObj.bsIndex.$li.addClass('active');
        tabObj.bsIndex.$content.addClass('active');
        this.tabArr.forEach(function(id, index) {
          if (index > 0) {
            tabObj[id].$li.remove();
            tabObj[id].$content.remove();
            tabObj[id] = null;
          }
        });
        this.tabArr.splice(1, this.tabArr.length - 1);
        this.activeTab = 'bsIndex'
        this.triggerScroll();
      },
      closeOthers: function(){
        var tabObj = this.$tabContentObj;
        var currId = this.activeTab;
        this.tabArr.forEach(function(id, index) {
          if (index > 0 && id != currId) {
            tabObj[id].$li.remove();
            tabObj[id].$content.remove();
            tabObj[id] = null;
          }
        });
        this.tabArr = ['bsIndex', currId];
        this.triggerScroll();
      },
      refreshTab: function (id, url) {
        var id = id || this.activeTab;
        var iframe = this.$tabContentObj[id].$content.children();
        if (iframe.length > 0) {
          if (url) {
            if (url.indexOf("http://") == -1) {
              url = webRoot + url;
            }
            iframe.attr('src', url);
          } else {
            iframe.attr('src', iframe.attr('src'));
          }
        }
      },
      getParentTab: function (id) {
        id = id || this.activeTab;
        var content;
        var pid = this.$tabContentObj[id].parent;
        if (pid) {
          content = this.$tabContentObj[pid].$content.children("iframe").contents()
        }
        return content;
      },
      scroll: function (type) {
        var _this = this;
        if (!this.timer) {
          return;
        }
        var leftDisNum = Number(this.$tab.css('left').replace('px', ''));
        if (leftDisNum <= 0) {
          var leftDis = Math.abs(leftDisNum);
          var dis = type === 'left' ? leftDis : this.tabWidth - this.maxWidth - leftDis;
          var distance = 0,
            time = 100;
          if (dis >= 60) {
            distance = 60;
          } else if (dis > 0) {
            distance = dis;
            time = dis / 60 * 100;
          } else {
            clearInterval(this.timer);
            this.$tab.stop(true).css('left', type === 'left' ? 0 : this.maxWidth - this.tabWidth);
            return;
          }
        } else {
          clearInterval(this.timer);
          this.$tab.stop(true).css('left', type === 'left' ? 0 : this.maxWidth - this.tabWidth);
          this.triggerScroll();
          return;
        }
        this.$tab.animate({
          left: type === 'left' ? "+=" + distance : "-=" + distance
        }, time, function () {
          _this.triggerScroll();
        });
      },
      triggerScroll: function () {
        var _this = this;
        if (!this.$tabLeft) {
          var tabLeft = document.createElement('div'),
            tabRight = document.createElement('div'),
            arrowLeft = document.createElement('i'),
            arrowRight = document.createElement('i');
          var $tabLeft = $(tabLeft),
            $tabRight = $(tabRight);
          $(arrowLeft).addClass('fa fa-angle-double-left');
          $(arrowRight).addClass('fa fa-angle-double-right');
          $tabLeft.addClass('tab-scroll tab-scroll-left').html(arrowLeft);
          $tabRight.addClass('tab-scroll tab-scroll-right').html(arrowRight);
          $tabLeft.on('mouseover', function () {
            _this.timer = setInterval(function () {
              _this.scroll('left');
            }, 100)
          });
          $tabLeft.on('mouseout', function () {
            clearInterval(_this.timer);
          })
          $tabRight.on('mouseover', function () {
            _this.timer = setInterval(function () {
              _this.scroll('right');
            }, 100)
          });
          $tabRight.on('mouseout', function () {
            clearInterval(_this.timer);
          })
          this.$tabLeft = $tabLeft;
          this.$tabRight = $tabRight;
          this.$tab.after(tabLeft).after(tabRight);
        }
        this.maxWidth = this.$container.width() - 50;
        this.tabWidth = 0;
        var tabObj = this.$tabContentObj;
        this.tabArr.forEach(function (el) {
          _this.tabWidth += tabObj[el].$li.width();
        })
        if (this.tabWidth > this.maxWidth) {
          var leftDis = Number(this.$tab.css('left').replace('px', ''));
          if (leftDis < 0) {
            this.$tabLeft.show();
          } else {
            this.$tabLeft.hide();
          }
          if (Math.abs(leftDis) + this.maxWidth < this.tabWidth) {
            this.$tabRight.show();
          } else {
            this.$tabRight.hide();
          }
        } else {
          this.$tabLeft.hide();
          this.$tabRight.hide();
        }
      },
      changeFrameHeight: function () {
        var height = parent.documentElement.clientHeight - 130;
        var tabObj = this.$tabContentObj;
        this.tabArr.forEach(function (item) {
          tabObj[item].$content.children('iframe').height(height);
        })
        this.triggerScroll();
      }
    }
    var tabClub;
    if (!window.top.bs_tabClub) {
      tabClub = new Tab();
      window.top.bs_tabClub = tabClub;
    } else {
      tabClub = window.top.bs_tabClub;
    }
    $.addTabs = function (options) {
      return tabClub.addTabs(options);
    };
    $.closeTab = function (id) {
      return tabClub.closeTab(id);
    };
    $.refreshTab = function (id, url) {
      return tabClub.refreshTab(id, url);
    };
    $.getParentTab = function (id) {
      return tabClub.getParentTab(id);
    };
  })